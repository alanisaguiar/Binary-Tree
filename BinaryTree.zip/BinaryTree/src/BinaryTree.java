import java.util.*;

public class BinaryTree {
    private Node root;
    private int size = 0;

    public boolean isEmpty() { 
        return root == null; 
    }
    public int size() { 
        return size; 
    }

    public void insert(int value) {
        Node newNode = new Node(value);

        if (isEmpty()) {
            root = newNode;
            size++;
            return;
        }

        Node auxNode = root;
        while (true) {
            if (value < auxNode.value) {
                if (auxNode.left == null) {
                    auxNode.left = newNode;
                    break;
                }
                auxNode = auxNode.left;
            } else if (value > auxNode.value) {
                if (auxNode.right == null) {
                    auxNode.right = newNode;
                    break;
                }
                auxNode = auxNode.right;
            } else {
                return;
            }
        }
        size++;
    }

    //PRE-ORDER
    public List<Integer> preOrder() {
        List<Integer> result = new ArrayList<>();
        preOrder(root, result);
        return result;
    }
    private void preOrder(Node n, List<Integer> result) {
        if (n == null) return;
        result.add(n.value);
        preOrder(n.left, result);
        preOrder(n.right, result);
    }

    //IN-ORDER
    public List<Integer> inOrder() {
        List<Integer> result = new ArrayList<>();
        inOrder(root, result);
        return result;
    }
    private void inOrder(Node n, List<Integer> result) {
        if (n == null) return;
        inOrder(n.left, result);
        result.add(n.value);
        inOrder(n.right, result);
    }

    //POST-ORDER
    public List<Integer> postOrder() {
        List<Integer> result = new ArrayList<>();
        postOrder(root, result);
        return result;
    }
    private void postOrder(Node n, List<Integer> result) {
        if (n == null) return;
        postOrder(n.left, result);
        postOrder(n.right, result);
        result.add(n.value);
    }

    //EM NÍVEL (BFS)
    public List<Integer> levelOrder() {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;

        Queue<Node> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            Node n = queue.poll();
            result.add(n.value);
            if (n.left  != null) queue.add(n.left);
            if (n.right != null) queue.add(n.right);
        }
        return result;
    }

    //constroi arvore de um vetor
    public static BinaryTree fromArray(int[] arr) {
        BinaryTree t = new BinaryTree();
        for (int v : arr) t.insert(v);
        return t;
    }

    //INSERTION SORT
    public static void insertionSort(int[] a) {
        for (int i = 1; i < a.length; i++) {
            int key = a[i];
            int j = i - 1;
            while (j >= 0 && a[j] > key) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = key;
        }
    }

    //SELECTION SORT        
    public static void selectionSort(int[] a) {
        for (int i = 0; i < a.length - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < a.length; j++) {
                if (a[j] < a[minIdx]) minIdx = j;
            }
            if (minIdx != i) {
                int tmp = a[i]; a[i] = a[minIdx]; a[minIdx] = tmp;
            }
        }
    }

    //BUBBLE SORT
    public static void bubbleSort(int[] a) {
        boolean trocou;
        for (int i = 0; i < a.length - 1; i++) {
            trocou = false;
            for (int j = 0; j < a.length - 1 - i; j++) {
                if (a[j] > a[j + 1]) {
                    int tmp = a[j]; a[j] = a[j + 1]; a[j + 1] = tmp;
                    trocou = true;
                }
            }
            if (!trocou) break;
        }
    }
    
    //mostra a arvore bonitinho (tostring)
    public String printTree() {
        if (root == null) return "(vazia)";
        StringBuilder sb = new StringBuilder();
        Queue<Node> q = new LinkedList<>();
        q.add(root);
        while (!q.isEmpty()) {
            int n = q.size();
            for (int i = 0; i < n; i++) {
                Node curr = q.poll();
                sb.append(curr.value).append(" ");
                if (curr.left != null) q.add(curr.left);
                if (curr.right != null) q.add(curr.right);
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
