import java.util.*;
import java.util.function.Consumer;

public class App {

    private static int[] toArray(List<Integer> list) {
        int[] a = new int[list.size()];
        for (int i = 0; i < list.size(); i++) a[i] = list.get(i);
        return a;
    }
    private static int[] copy(int[] a) { return Arrays.copyOf(a, a.length); }

    private static int[] sortedAscUnique(int[] a) {
        return Arrays.stream(a).distinct().sorted().toArray();
    }
    private static int[] desc(int[] asc) {
        int[] d = new int[asc.length];
        for (int i = 0; i < asc.length; i++) d[i] = asc[asc.length - 1 - i];
        return d;
    }

    //Gera ordem de inserção pra construir BST balanceada
    private static void buildMedianOrder(int[] asc, int l, int r, List<Integer> out) {
        if (l > r) return;
        int mid = (l + r) >>> 1;
        out.add(asc[mid]);
        buildMedianOrder(asc, l, mid - 1, out);
        buildMedianOrder(asc, mid + 1, r, out);
    }

    private static BinaryTree buildBalancedBSTFromValues(int[] values) {
        int[] asc = sortedAscUnique(values);
        List<Integer> order = new ArrayList<>();
        buildMedianOrder(asc, 0, asc.length - 1, order);
        BinaryTree t = new BinaryTree();
        for (int v : order) t.insert(v);
        return t;
    }

    private static BinaryTree buildUnbalancedBSTFromValues(int[] values) {
        int[] asc = sortedAscUnique(values);
        BinaryTree t = new BinaryTree();
        // inserindo em ordem crescente -> árvore desbalanceada à direita
        for (int v : asc) t.insert(v);
        return t;
    }

    // ======== ORDENAÇÃO ========
    private static void imprimirBlocoOrdenacao(String titulo, int[] base) {
        System.out.println("\n" + titulo);

        int[] a1 = copy(base);
        int[] a2 = copy(base);
        int[] a3 = copy(base);

        BinaryTree.insertionSort(a1);
        BinaryTree.selectionSort(a2);
        BinaryTree.bubbleSort(a3);

        System.out.println("- insertion sort");
        System.out.println("  vetor:  " + Arrays.toString(a1));

        System.out.println("- selection sort");
        System.out.println("  vetor:  " + Arrays.toString(a2));

        System.out.println("- bubble sort");
        System.out.println("  vetor:  " + Arrays.toString(a3));
    }

    // ======== BENCHMARK ========
    private static long timeNs(Consumer<int[]> sorter, int[] data) {
        int[] a = copy(data);              
        long t0 = System.nanoTime();
        sorter.accept(a);
        long t1 = System.nanoTime();
        return t1 - t0;
    }

    private static void printAsymptoticAnalysis() {
        System.out.println("\n=== Análise Assintótica ===");
        System.out.println("Insertion Sort:   melhor Θ(n), médio Θ(n^2), pior Θ(n^2)");
        System.out.println("Selection Sort:   melhor Θ(n^2), médio Θ(n^2), pior Θ(n^2)");
        System.out.println("Bubble Sort*:     melhor Θ(n), médio Θ(n^2), pior Θ(n^2)");
    }

    private static void benchmarkOneBlock(
            String tituloBloco,
            int[] base,
            Map<String, Consumer<int[]>> algs
    ) {
        int[] asc = Arrays.stream(base).sorted().toArray();  // melhor caso p/ insertion/bubble
        int[] avg = copy(base);                              // caso médio: como veio do percurso
        int[] dsc = desc(asc);                               // pior caso p/ insertion/bubble

        System.out.println("\n" + tituloBloco);

        for (Map.Entry<String, Consumer<int[]>> e : algs.entrySet()) {
            String nome = e.getKey();
            Consumer<int[]> sorter = e.getValue();

            long tBest  = timeNs(sorter, asc);
            long tAvg   = timeNs(sorter, avg);
            long tWorst = timeNs(sorter, dsc);

            System.out.println("- " + nome);
            System.out.println("  melhor(ns): " + tBest);
            System.out.println("  médio(ns):  " + tAvg);
            System.out.println("  pior(ns):   " + tWorst);
        }
    }

    //arvore gerada em cada percurso
    private static void mostrarArvoreGeradaPorPercurso(String titulo, List<Integer> percurso) {
        BinaryTree t = new BinaryTree();
        for (int v : percurso) t.insert(v);
        System.out.println("\n" + titulo);
        System.out.println("percurso base: " + percurso);
        System.out.println("forma da árvore (níveis):");
        System.out.print(t.printTree());
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //entrada
        System.out.println("Digite os valores (separados por espaço). Ex.: 7 3 9 1 5 8 10");
        String line = sc.nextLine().trim();
        if (line.isEmpty()) {
            System.out.println("Entrada vazia. Encerrando.");
            return;
        }
        String[] parts = line.split("\\s+");
        List<Integer> vals = new ArrayList<>();
        for (String p : parts) {
            try { vals.add(Integer.parseInt(p)); }
            catch (NumberFormatException ignore) {}
        }
        if (vals.isEmpty()) {
            System.out.println("Nenhum inteiro válido foi digitado. Encerrando.");
            return;
        }
        int[] inputValues = vals.stream().mapToInt(Integer::intValue).toArray();

        //monta as duas arvores
        BinaryTree treeBalanced   = buildBalancedBSTFromValues(inputValues);
        BinaryTree treeUnbalanced = buildUnbalancedBSTFromValues(inputValues);

        //mostra arvore em cada percurso
        System.out.println("\n=== ÁRVORE COMPLETA (balanceada) ===");
        System.out.println(treeBalanced.printTree());

        mostrarArvoreGeradaPorPercurso("Árvore com o preorder (COMPLETA)",   treeBalanced.preOrder());
        mostrarArvoreGeradaPorPercurso("Árvore com o postorder (COMPLETA)",  treeBalanced.postOrder());
        mostrarArvoreGeradaPorPercurso("Árvore com o inorder (COMPLETA)",    treeBalanced.inOrder());
        mostrarArvoreGeradaPorPercurso("Árvore em nivel (COMPLETA)",         treeBalanced.levelOrder());

        System.out.println("\n=== ÁRVORE DESBALANCEADA (tendência a um lado) ===");
        System.out.println(treeUnbalanced.printTree());

        mostrarArvoreGeradaPorPercurso("Árvore com o preorder (DESBALANCEADA)",   treeUnbalanced.preOrder());
        mostrarArvoreGeradaPorPercurso("Árvore com o postorder (DESBALANCEADA)",  treeUnbalanced.postOrder());
        mostrarArvoreGeradaPorPercurso("Árvore com o inorder (DESBALANCEADA)",    treeUnbalanced.inOrder());
        mostrarArvoreGeradaPorPercurso("Árvore em nivel (DESBALANCEADA)",         treeUnbalanced.levelOrder());

        //ordenações
        int[] preBal   = toArray(treeBalanced.preOrder());
        int[] postBal  = toArray(treeBalanced.postOrder());
        int[] inBal    = toArray(treeBalanced.inOrder());
        int[] levelBal = toArray(treeBalanced.levelOrder());

        int[] preUnb   = toArray(treeUnbalanced.preOrder());
        int[] postUnb  = toArray(treeUnbalanced.postOrder());
        int[] inUnb    = toArray(treeUnbalanced.inOrder());
        int[] levelUnb = toArray(treeUnbalanced.levelOrder());

        // COMPLETA
        imprimirBlocoOrdenacao("Árvore com o preorder (COMPLETA)", preBal);
        imprimirBlocoOrdenacao("Árvore com o postorder (COMPLETA)", postBal);
        imprimirBlocoOrdenacao("Árvore com o inorder (COMPLETA)", inBal);
        imprimirBlocoOrdenacao("Árvore em nivel (COMPLETA)", levelBal);

        // DESBALANCEADA
        imprimirBlocoOrdenacao("Árvore com o preorder (DESBALANCEADA)", preUnb);
        imprimirBlocoOrdenacao("Árvore com o postorder (DESBALANCEADA)", postUnb);
        imprimirBlocoOrdenacao("Árvore com o inorder (DESBALANCEADA)", inUnb);
        imprimirBlocoOrdenacao("Árvore em nivel (DESBALANCEADA)", levelUnb);

        // ===== ANÁLISE ASSINTÓTICA =====
        printAsymptoticAnalysis();

        Map<String, Consumer<int[]>> algs = new LinkedHashMap<>();
        algs.put("insertion sort", BinaryTree::insertionSort);
        algs.put("selection sort", BinaryTree::selectionSort);
        algs.put("bubble sort",    BinaryTree::bubbleSort);

        System.out.println("\n=== Tempo de Execução ===");

        // COMPLETA
        benchmarkOneBlock("Árvore com o preorder (COMPLETA)",   preBal,   algs);
        benchmarkOneBlock("Árvore com o postorder (COMPLETA)",  postBal,  algs);
        benchmarkOneBlock("Árvore com o inorder (COMPLETA)",    inBal,    algs);
        benchmarkOneBlock("Árvore em nivel (COMPLETA)",         levelBal, algs);

        // DESBALANCEADA
        benchmarkOneBlock("Árvore com o preorder (DESBALANCEADA)",   preUnb,   algs);
        benchmarkOneBlock("Árvore com o postorder (DESBALANCEADA)",  postUnb,  algs);
        benchmarkOneBlock("Árvore com o inorder (DESBALANCEADA)",    inUnb,    algs);
        benchmarkOneBlock("Árvore em nivel (DESBALANCEADA)",         levelUnb, algs);


        
        



    }
}
